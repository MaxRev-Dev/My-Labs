import io 
import time
import errno
from os import getcwd, listdir, mkdir 
from os.path import isfile, join, isdir

path = join(getcwd(), 'files')
if ( isdir(path) == False):
    print('Can\'t fing \'files\' directory')
    print('Creating new one in ' + getcwd())
    mkdir(getcwd(), 'files')

files = lambda: [f for f in listdir(path) if isfile(join(path, f))]
if (files() == []):
    print('Waiting for files...')  
    while (files() == []):
        time.sleep(1000)


print('WorkDir is '+ path)
print()
print('Files:\n' +"\n".join(files()))

for filename in files():  
        if filename.endswith('.txt'): 
           try:
                f = open(join(path,filename),'r')
                print('File contents:\n' +"".join(f.readlines())) 
                f.close();
                f = open(join(path,filename),'a')
                text = input("Enter content to append: ");
                f.write(text)
                f.close()
           except IOError as x:
                if (x.errno == errno.ENOENT):
                    print(filename + '- does not exist')
                elif x.errno == errno.EACCES:
                     print(filename + '- cannot be read')
                else:
                     print(filename + '- some other error')
        else:
            print('\nType this '+filename+' is not supported\n') 